/*
 *
 *        Name: linux/fs/cms/cmsfsmsg.h (C source header file)
 *              localization strings for the CMS filesystem package
 *        Date: 2000-Aug-02 (Wed)
 *              Copyright � 2000
 *              Rick Troth <rtroth@bmc.com>
 *              BMC Software, Inc., Houston, Texas, USA
 *
 */
 
/*  A place for I18N.  */
 
