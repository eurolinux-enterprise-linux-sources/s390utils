/* 
 * 
 *	  Name: cmsfsls.c (C source) 
 *		list the files on a CMS FS volume 
 *		in traditional Unix 'ls' format. 
 * 
 */ 
 
 
